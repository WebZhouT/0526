import React, { Component } from 'react'
import Headling from './Heading/Headling';
import Content from './Body/Content';
import './App.css';
import SignupAndSigninPage from './Body/SignupAndSigninPage';
import ResetPwd from './Body/ResetPwd';
import Feedback from './Body/Feedback';
import Help from './Body/Help';
import axios from 'axios';

export default class App extends Component {
  // localhost
  lh = 'http://localhost:9999'


  state = {
    flagSigninAndSignup: false,
    username: 'Guest',
    userId:'',
    flagResetPwd: false,
    flagFeedback: false,
    flagHelp: false
  }
  //display user signup/signin page
  changeFlagSigninAndSignup = () => {
    this.setState({
      flagSigninAndSignup: !this.state.flagSigninAndSignup
    })
  }

  //the username after user login
  getUsername = (username) => {
    this.setState({
      username
    })
  }

  //userId from cookie
  getUserId = (userId) => {
    this.setState({
      userId
    })
  }

  changeFlagResetPwd = () => {
    this.setState({
      flagResetPwd: !this.state.flagResetPwd
    })
  }

  changeFlagFeedback = () => {
    this.setState({
      flagFeedback: !this.state.flagFeedback
    })
  }

  changeFlagHelp = () => {
    this.setState({
      flagHelp: !this.state.flagHelp
    })
  }

  render() {
    const { flagSigninAndSignup, username, flagResetPwd, flagFeedback, flagHelp, userId } = this.state
    return (
      <div className="App">

        {/* User Signin/Signup components */}
        {
          flagSigninAndSignup ? <SignupAndSigninPage changeFlagSigninAndSignup={this.changeFlagSigninAndSignup} getUsername={this.getUsername} /> : ''
        }


        {
          flagResetPwd ? <ResetPwd changeFlagResetPwd={this.changeFlagResetPwd} /> : ''
        }

        {
          flagFeedback ? <Feedback changeFlagFeedback={this.changeFlagFeedback} /> : ''
        }

        {
          flagHelp ? <Help changeFlagHelp={this.changeFlagHelp} /> : ''
        }

        {/* Heading components */}
        <Headling />


        {/* Content components */}
        <Content changeFlagSigninAndSignup={this.changeFlagSigninAndSignup} username={username} changeFlagResetPwd={this.changeFlagResetPwd} changeFlagFeedback={this.changeFlagFeedback} changeFlagHelp={this.changeFlagHelp} userId = {userId} />




      </div>
    )
  }

  getCookie = (i) => {
    var arr = document.cookie.match(new RegExp("(^|\\s)" + i + "=([^;]+)(;|$)"));
    if (arr != null) {
      return decodeURIComponent(arr[2]);//token
    } else {
      return null;
    }
  }

  removeCookie = (e) => {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = this.getCookie(e);
    if (cval) {
      document.cookie = e + "=" + cval + ";expires=" + exp.toUTCString();
      return cval
    }
  }

  componentDidMount() {
    var token = this.getCookie('token');
    axios({
      headers: {
        'Content-Type': 'application/json',
        'x-api-token': token
      },
      method: 'GET',
      url: this.lh + '/api/info'
    }).then(e => {
      if (e.data.code === 200) {
        this.getUserId(e.data.data.id);
        this.getUsername(e.data.data.username);
      } else if (e.data.code === 500) {
        this.removeCookie('id');
        this.removeCookie('username');
        this.removeCookie('token');

      }
    })
  }
}