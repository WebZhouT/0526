import React, { Component } from 'react'

export default class RegisterPage extends Component {
  state = {
    flagOverlay: true
  }
  changeOverlay = () => {
    this.setState({
      flagOverlay: !this.state.flagOverlay
    })
  }
  render() {
    const { flagOverlay } = this.state;
    const { changeFlagRegister } = this.props
    return (
      <div className='signUpBG'>


        {/* 整体布局 */}
        <div className="container right_panel_active">
          {/* 注册框 */}
          <div className="container_form container_signUp">
            <form action="#" className='form' id='form1'>
              <h2 className='form_title'>Sign up Here</h2>
              <input type="text" placeholder='Username' className='input' />
              <input type="email" placeholder='Email address' className='input' />
              <input type="password" placeholder='Password' className='input' />
              <button className='button11'>Sign up</button>
            </form>
          </div>

          {/* 登入框 */}
          <div className="container_form container_signIn">
            <form action="#" className='form' id='form2'>
              <h2 className='form_title'>Sign in Here</h2>
              <input type="email" placeholder='Email address' className='input' />
              <input type="password" placeholder='Password' className='input' />
              <a href="#" className='link'>Forgot your password?</a>
              <button className='button11' onClick={() => {

              }}>Sign in</button>
            </form>
          </div>
          <div style={{ position: 'absolute', width: '100%', zIndex:'999'}}>
            <button onClick={() => {
              changeFlagRegister()
            }} style={{position: 'absolute',right:'10px',border:'none',background:'transparent'}}><i className="bi bi-x-lg"></i></button>
          </div>



          {flagOverlay ? <div className="overlay_left"><button className='button11 overlayBtn' onClick={() => { this.changeOverlay() }}>Already have an account? Click here to sign in!</button></div> : <div className="overlay_right"><button className='button11 overlayBtn' onClick={() => { this.changeOverlay() }}>Do not have an account? Sign up here!</button></div>}

        </div>
      </div>
    )
  }
}
