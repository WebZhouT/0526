import React, { Component } from 'react'
import E from 'wangeditor'
import i18next from 'i18next'
import axios from 'axios';

export default class PlaintNotes111 extends Component {

  // localhost
  lh = 'http://localhost:9999'

  constructor(props) {

    super(props);
    this.state = {
      editorContent: '',
      editor: ''
    };
  }

  createFile = async (fileType) => {
    var filename = document.getElementById('filename').value;
    var folderID = 0;

    // get folderId from Cookie
    var toWhichFolder = document.getElementById('toWhichFolder').value;
    var foldersFromCookie = this.getCookie('folders');
    var res = JSON.parse(foldersFromCookie);
    var resObject = Object.keys(res);
    var len = resObject.length;
    if (len !== 0) {
      let obj = res.find(o => o.name === toWhichFolder);
      if (obj) {
        folderID = obj.id;
      } else {
        alert('Sorry, no existing folder!')
      }
    }

    var noteContent = this.state.editor.txt.html()
    let noteParameter = JSON.stringify({ name: filename, folderId: folderID, userId: this.props.userId, type: fileType, content: noteContent, delFlag: 0 })

    await axios({
      headers: { 'Content-Type': 'application/json' },
      method: 'POST',
      url: this.lh + '/api/note',
      data: noteParameter
    }).catch(e => {
      console.log(e);
    })
    window.location.reload()
  }

  deleteFile = async (nodeId) => {
    if (this.props.noteId !== '') {
      await axios({
        method: 'DELETE',
        url: this.lh + '/api/note/'+this.props.noteId,
      }).catch((e)=>{
        console.log(e);
      })
      window.location.reload()
    }else{
      alert('No note selected')
    }
  }

  saveFile = async (fileType2) => {
    if (!isNaN(this.props.noteId)) {
      var filename = document.getElementById('filename').value;
      var folderID = 0;

      // get folderId from Cookie
      var toWhichFolder = document.getElementById('toWhichFolder').value;
      var foldersFromCookie = this.getCookie('folders');
      var res = JSON.parse(foldersFromCookie);
      var resObject = Object.keys(res);
      var len = resObject.length;
      if (len !== 0) {
        let obj = res.find(o => o.name === toWhichFolder);
        if (obj) {
          folderID = obj.id;
        } else {
          alert('Sorry, no existing folder!')
        }
      }

      var noteContent = this.state.editor.txt.html()
      let noteParameter = JSON.stringify({ id: this.props.noteId, name: filename, folderId: folderID, userId: this.props.userId, type: fileType2, content: noteContent, delFlag: 0 })

      await axios({
        headers: { 'Content-Type': 'application/json' },
        method: 'PUT',
        url: this.lh + '/api/note',
        data: noteParameter
      }).then(e => {
        console.log(e);
      })
    }
  }

  componentDidUpdate() {
    this.state.editor.txt.html(this.props.content)
  }
  componentDidMount() {

    const elemMenu = this.refs.editorElemMenu;
    const elemBody = this.refs.editorElemBody;

    const editor = new E(elemMenu, elemBody)

    // 使用 onchange 函数监听内容的变化，并实时更新到 state 中
    editor.config.lang = 'en'
    editor.config.zIndex = 1


    editor.i18next = i18next
    editor.config.fontNames = ['Arial', 'Tahoma', 'Verdana', 'Times New Roman', 'Courier New']
    editor.config.onchange = html => {
      // this.setState({
      //   editorContent: editor.txt.text()
      // })
    }
    editor.config.menus = [
      'bold',  // 粗体
      'fontSize',  // 字号
      'fontName',  // 字体
      'italic',  // 斜体
      'underline',  // 下划线
      'strikeThrough',  // 删除线
      'foreColor',  // 文字颜色
      'link',  // 插入链接
      'list',  // 列表
      'image',  // 插入图片
      'table',  // 表格
      'undo',  // 撤销
      'redo'  // 重复
    ]
    editor.config.uploadImgShowBase64 = true
    editor.create()
    this.setState({
      editor
    })
  };

  // get cookies => folders
  getCookie = (i) => {
    var arr = document.cookie.match(new RegExp("(^|\\s)" + i + "=([^;]+)(;|$)"));
    if (arr != null) {
      return decodeURIComponent(arr[2]);//1
    } else {
      return null;
    }
  }

  render() {
    const { noteId } = this.props
    
    return (
      <div>
        <div className="" >
          <div className="text-area" >

            {/* Rich text editor menu */}
            <div ref="editorElemMenu" style={{ backgroundColor: '#f1f1f1', border: "1px solid #ccc" }} className="editorElem-menu">
            </div>
            <div style={{ display: 'flex', justifyContent: 'center' }}>

              {/* download file btn */}
              <button title='download the file' className='btnStarTrash' style={{ marginLeft: '2px', marginRight: '10px', marginTop: '10px' }}><i className="bi bi-download"></i></button>


              {/* delete file btn */}
              <button title='Delete the file' className='btnStarTrash' style={{ marginLeft: '2px', marginRight: '10px', marginTop: '10px' }} onClick= {async() => {
                this.deleteFile(noteId)
              }} ><i className="bi bi-trash"></i></button>

              {/* file name input */}
              <input type="text" placeholder='file name' id='filename' style={{ resize: 'none', width: '10em', fontSize: '15px', border: '2px solid #0367a6', borderRadius: '20px', marginTop: '10px', marginRight: '5px' }} />
              <input type="text" placeholder='to which folder...' id='toWhichFolder' style={{ resize: 'none', width: '10em', fontSize: '15px', border: '2px solid #0367a6', borderRadius: '20px', marginTop: '10px' }} />


              {/* Create files btn */}
              <button title='create a file' className="btn dropdown-toggle " type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style={{ fontSize: '18px', color: 'black', position: 'relative', top: '7px', height: '43px', border: '1px solid #0367a6', borderRadius: '20px', fontWeight: 'bold', width: '93px', marginLeft: '5px' }}>
                Create
              </button>
              <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <li><button className="dropdown-item" onClick={() => { this.createFile(0) }}>.txt</button></li>
                <li><button className="dropdown-item" onClick={() => { this.createFile(1) }}>.md</button></li>
                <li><button className="dropdown-item" onClick={() => { this.createFile(0) }}>.pdf(including images)</button></li>
              </ul>

              {/* Save files btn */}
              <button title='save the file' className="btn dropdown-toggle " type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style={{ fontSize: '18px', color: 'black', position: 'relative', top: '7px', height: '43px', border: '1px solid #0367a6', borderRadius: '20px', fontWeight: 'bold', width: '93px', marginLeft: '5px' }}>
                Save
              </button>
              <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <li><button className="dropdown-item" onClick={() => { this.saveFile(0) }}>.txt</button></li>
                <li><button className="dropdown-item" onClick={() => { this.saveFile(1) }}>.md</button></li>
                <li><button className="dropdown-item" onClick={() => { this.saveFile(0) }}>.pdf(including images)</button></li>
              </ul>
            </div>

            {/* Rich text editor body */}
            <div style={{ marginTop: '10px', height: '100%' }}>
              <div style={{ padding: "0 10px", overflowY: "scroll", height: '86vh', border: "1px solid #ccc", borderTop: "none" }} ref="editorElemBody" className="editorElem-body">
              </div>

            </div>
          </div>
        </div>

      </div>


    )
  }




}
