import React, { Component } from 'react';
import axios from 'axios';


export default class SearchOwnFiles extends Component {
  lh = 'http://localhost:9999'
  state ={
    fileList: []
  }
  getCookie = (i) => {
    var arr = document.cookie.match(new RegExp("(^|\\s)" + i + "=([^;]+)(;|$)"));
    if (arr != null) {
      return decodeURIComponent(arr[2]);//1
    } else {
      return null;
    }
  }

  getFile = async (name)=>{
    const a = await axios({
      headers: { 'Content-Type': 'application/json' },
      method: 'POST',
      url: this.lh + '/api/note/list',
      data: {
        userId: this.getCookie('id'),
        name
      }
    }).catch(e => {
      console.log('Went wrong');
    })
    this.setState({
      fileList: a.data.data

    })
  }

  render() {
    const { changeFlagSearchOwnFiles, receiveNote } = this.props
    const { fileList } = this.state
    return (
      <div style={{width:'100%',height:'100%',backgroundColor:'#e9e9e9'}}>
        {/* close button */}
        <button onClick={() => {
          changeFlagSearchOwnFiles(false)
        }} style={{float:'right',background:'transparent',border:'none'}}><i className="bi bi-x-circle"></i></button>

        {/* search box */}
        <div className='searchBox'>
          <div>
            <h4>Search your own notes here</h4>
          </div>

          {/* Other users' notes search bar */}
          <div style={{ float: 'right', padding: '6px' }}>
            <input type="text" placeholder="Search from your notes..." className='searchInput' id='ownSearchInput'></input>
            <button style={{ border: 'none', background: 'transparent' }} onClick={()=>{
              this.getFile(document.getElementById('ownSearchInput').value)
            }}><i className="bi bi-search"></i></button>
          </div>

          {/* Search reseults */}
          <div className='searchReseults'>
            <h5>Search Results</h5>
            {
              fileList.map((item, index)=>{
                return <div key={index+'-'+item.name+''}><button onClick={()=>{
                  changeFlagSearchOwnFiles(false);
                  receiveNote(item.content, item.id);
                }}>{item.name}</button></div>
              })
            }
            
          </div>

        </div>

      </div>
    )
  }
}
