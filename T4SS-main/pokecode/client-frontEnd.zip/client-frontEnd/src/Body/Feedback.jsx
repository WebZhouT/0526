import axios from 'axios'
import React, { Component } from 'react'

export default class Feedback extends Component {
  state = {
    feedBackList : []
  }
  // localhost
  lh = 'http://localhost:9999'

  componentDidMount = async()=>{
    let feedBackList = await axios({
        headers:{'Content-Type': 'application/json'},
        method:'POST',
        url: this.lh + '/api/feedback/list',  
    })
    this.setState({
      feedBackList : feedBackList.data.data
    })
  }

  render() {
    const { changeFlagFeedback } = this.props;
    const { feedBackList } = this.state;
    return (
      <div className='settingBox'>
        <div className='settingDiv' style={{ height: '80%' }}>
          <button onClick={() => {
            changeFlagFeedback()
          }} style={{ position: 'absolute', right: '10px', top: '10px', border: 'none', background: 'transparent' }}><i className="bi bi-x-lg"></i></button>

          {/* Feedback box */}
          <div style={{ display: 'flex', flexDirection: 'column', width: '95%', height: '90%', alignItems: 'center' }}>

            {/* Feedbacks from all users */}
            <div className='feedbackBoard'>
              <h2>Users' Feedback Board</h2>
              {
                feedBackList.map((e,index) => {
                  return <div key={index}>{e.content}</div>
                })
              }

            </div>

            {/* Write a new feedback */}
            <div className="md-form amber-textarea active-amber-textarea feedbackTexarea">
              <textarea id='feebackContent' className="md-textarea form-control" row="3" style={{ resize: 'none', width: '100%', height: '95%' }}></textarea>
              <label style={{ position: 'relative', top: '15px', fontSize: '18px' }} >&nbsp;&nbsp;Feedback Textarea</label>
              <button style={{ fontSize: '18px', color: 'black',height: '43px', border: '1px solid #0367a6', borderRadius: '20px', fontWeight: 'bold', width: '93px',float:'right',position: 'relative', top: '5px', }} onClick={()=>{
                var feedbackContent = document.getElementById('feebackContent').value;
                var uidFeedback = 0;
                var like = 0;
                console.log(feedbackContent);
                let jsonFeedback = JSON.stringify({
                  userId:uidFeedback,
                  content:feedbackContent,
                  like:like
                });
                axios({
                  headers:{'Content-Type': 'application/json'},
                  method:'POST',
                  url: this.lh + '/api/feedback',
                  data:jsonFeedback
                }).then(e=>{
                  alert('Thanks for your feedback!')
                })
              }}>Submit</button>
            </div>

          </div>


        </div>

      </div>
    )
  }
}
