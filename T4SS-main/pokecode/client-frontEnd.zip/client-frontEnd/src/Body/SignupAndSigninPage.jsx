import React, { Component } from 'react'
import axios from 'axios'

export default class SignupAndSigninPage extends Component {
  // localhost
  lh = 'http://localhost:9999'


  state = {
    flagOverlay: true,
    
  }

  // Switch signup and signin pages
  changeOverlay = () => {
    this.setState({
      flagOverlay: !this.state.flagOverlay
    })
  }


  render() {
    const { flagOverlay } = this.state;
    const { changeFlagSigninAndSignup, getUsername } = this.props

    return (

      <div className='signupAndSigninBG'>
        {/* 整体布局 */}
        <div className="container right_panel_active">

          {/* Sign up page */}
          <div className="container_form container_signUp">
            <form action="#" className='form' id='form1' name="signupForm">
              <h2 className='form_title'>Sign up Here</h2>
              <input type="text" placeholder='Username' className='input' id="signupUsername" />
              <input type="password" placeholder='Password' className='input' id="signupPwd" />

              <button className='button11' onClick={() => {
                var un = document.getElementById('signupUsername').value;
                var pwd = document.getElementById('signupPwd').value;
                let json = JSON.stringify({ username: un, password: pwd })
                axios({
                  headers: { 'Content-Type': 'application/json' },
                  method: 'POST',
                  url: this.lh + '/api/reg',
                  data: json
                }).then(e => {

                  if (e.data.code === 200) {
                    alert('Yeh, registed successfully!');
                    this.changeOverlay();

                  } else {
                    alert('Ohno, this account already exists.')
                  }
                })
              }}>Sign up</button>
            </form>
          </div>


          {/* Sign in page */}
          <div className="container_form container_signIn">
            <form action="#" className='form' id='form2'>
              <h2 className='form_title'>Sign in Here</h2>
              <input type="text" placeholder='Username' className='input' id='signinUsername' />
              <input type="password" placeholder='Password' className='input' id='signinPwd' />
              

              {/* Signin button */}
              <button className='button11' onClick={() => {
                var un = document.getElementById('signinUsername').value;
                var pwd = document.getElementById('signinPwd').value;
                let json = JSON.stringify({ username: un, password: pwd })
                axios({
                  headers: { 'Content-Type': 'application/json' },
                  method: 'POST',
                  url: this.lh + '/api/login',
                  data: json
                }).then(e => {


                  if (e.data.code === 200) {

                    alert('Yeh, sign in successfully!');

                    // save id/username/token in cookies
                    var date = new Date().getTime();
                    var newD = new Date(date + 30 * 24 * 60 * 60 * 1000);//加上有效期时间后再转换成时间对象

                    document.cookie = "id=" + e.data.data.id + "; expires=" + newD.toUTCString();
                    document.cookie = "username=" + e.data.data.username + "; expires=" + newD.toUTCString();
                    document.cookie = "token=" + e.data.token + "; expires=" + newD.toUTCString();

                    changeFlagSigninAndSignup();//close Signin page after user successfully login
                    getUsername(e.data.data.username);//get username for displaying on the left components

                  } else {
                    alert('Ohno, wrong username or password.')
                  }
                })
              }}>Sign in</button>
            </form>
          </div>

          {/* close button on the right-top */}
          <div style={{ position: 'absolute', width: '100%', zIndex: '999' }}>
            <button onClick={() => {
              changeFlagSigninAndSignup();
            }} style={{ position: 'absolute', right: '10px', border: 'none', background: 'transparent' }}><i className="bi bi-x-lg"></i></button>
          </div>


          {/* Switch Signup and Signin pages */}
          {flagOverlay ? <div className="overlay_left"><button className='button11 overlayBtn' onClick={() => { this.changeOverlay() }}>Already have an account? Click here to sign in!</button></div> : <div className="overlay_right"><button className='button11 overlayBtn' onClick={() => { this.changeOverlay() }}>Do not have an account? Sign up here!</button></div>}

        </div>
      </div>
    )
  }


}
