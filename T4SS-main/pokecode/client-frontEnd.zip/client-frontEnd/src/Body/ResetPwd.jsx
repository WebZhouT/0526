import React, { Component } from 'react'
import axios from 'axios';

export default class ResetPwd extends Component {
  //localhost
  lh = 'http://localhost:9999'

  getCookie = (i) => {
    var arr = document.cookie.match(new RegExp("(^|\\s )" + i + "=([^;]+)(;|$)"));
    if (arr != null) {
      return decodeURIComponent(arr[2]);//1
    } else {
      return null;
    }
  }

  render() {
    const { changeFlagResetPwd } = this.props
    return (

      <div className='settingBox'>
        <div className='settingDiv' style={{height:'50%'}}>
          <h2 className='form_title'>Reset your password here</h2>
          <button onClick={() => {
            changeFlagResetPwd()
          }} style={{ position: 'absolute', right: '10px', top: '10px', border: 'none', background: 'transparent' }}><i className="bi bi-x-lg"></i></button>
          <input type="password" placeholder='Old password' className='input' style={{ width: '80%' }} id='oldpwd' />
          <input type="password" placeholder='New password' className='input' style={{ width: '80%' }} id='newpwd' />
          <button className='button11' style={{ marginTop: '1.5rem' }} onClick={() => {

            var oldpwd = document.getElementById('oldpwd').value;
            var newpwd = document.getElementById('newpwd').value;
            let json = JSON.stringify({ id: this.getCookie("id"), password: oldpwd, newPwd:newpwd })
            if (oldpwd === '' || newpwd === '') {
              alert('Please enter your old passsword or new password.')
            } else if(oldpwd === newpwd) {
              alert('New password and old password are the same.');
            }else{
              axios({
                headers: { 'Content-Type': 'application/json' },
                method: 'POST',
                url: this.lh + '/api/pwd',
                data: json
              }).then(e => {

                if (e.data.code === 200) {

                  alert('Password reseted successfully!');
                  changeFlagResetPwd();//close reset page after user's password successfully reset

                } else {
                  alert('Ohno, please enter old password correctly.')
                }
              })
            }
          }}>
            Reset
          </button>
        </div>

      </div>
    )
  }
}
