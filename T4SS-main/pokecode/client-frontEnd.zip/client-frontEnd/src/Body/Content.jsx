import React, { Component } from 'react'
import LeftContent from './leftContent'
import RightContent from './RightContent'
import SearchOwnFiles from './SearchOwnFiles'
import PlaintNotes from './PlaintNotes'
import StarredFiles from './StarredFiles'
import Trash from './Trash'

export default class Content extends Component {

  state = {
    flagSearchOwnFiles: false,
    flagStarredFiles: false,
    flagTrash: false,
    noteContent:'',
    noteId: ''
  }

  receiveNote = (content,id) =>{
    this.setState({
      noteContent: content,
      noteId: id
    })
  }


  // Seach user's own files
  changeFlagSearchOwnFiles = (bool) => {
    this.setState({
      flagSearchOwnFiles: bool
    })
  }

  //Starred files page
  changeFlagStarredFiles = (bool) => {
    this.setState({
      flagStarredFiles: bool
    })
  }

  //Trash Page
  changeFlagTrash = (bool) => {
    this.setState({
      flagTrash: bool
    })
  }

  

  render() {
    const { changeFlagSigninAndSignup, username, changeFlagResetPwd, changeFlagFeedback, changeFlagHelp, userId } = this.props
    const { flagSearchOwnFiles, flagStarredFiles, flagTrash, noteContent, noteId } = this.state
    return (
      <div style={{ width: 100 + '%', height: 95 + '%', display: 'flex' }}>
        {/* Left components */}
        <div className="bodyPage">
          <LeftContent changeFlagSigninAndSignup={changeFlagSigninAndSignup} changeFlagSearchOwnFiles={this.changeFlagSearchOwnFiles} username={username} changeFlagResetPwd={changeFlagResetPwd} changeFlagFeedback={changeFlagFeedback} changeFlagHelp={changeFlagHelp} changeFlagStarredFiles={this.changeFlagStarredFiles} changeFlagTrash={this.changeFlagTrash} changeFlagPlainNotes={this.changeFlagPlainNotes} receiveNote = {this.receiveNote}/>
        </div>


        {/* Mid components -> search user's own files / Starred files / Trash / make plaint notes*/}
        <div className="bodyPage">

          {

          flagSearchOwnFiles ? <SearchOwnFiles changeFlagSearchOwnFiles={this.changeFlagSearchOwnFiles} receiveNote = {this.receiveNote} /> : flagStarredFiles ? <StarredFiles changeFlagStarredFiles={this.changeFlagStarredFiles} /> : flagTrash ? <Trash changeFlagTrash={this.changeFlagTrash} /> : <PlaintNotes userId={userId} content = {noteContent} noteId = {noteId}/>

          }

        </div>


        {/* Right components */}
        <div className="bodyPage">
          <RightContent />
        </div>
      </div>
    )
  }
}
