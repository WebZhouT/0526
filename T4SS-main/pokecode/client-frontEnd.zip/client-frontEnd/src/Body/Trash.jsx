import React, { Component } from 'react'

export default class Trash extends Component {
  // localhost
  lh = 'http://localhost:9999'


  render() {
    const { changeFlagTrash } = this.props
    return (

      <div style={{ width: '100%', height: '100%' }}>
        {/* close button */}
        <button onClick={() => {
          changeFlagTrash(false)
        }} style={{ float: 'right', border: 'none', background: 'transparent' }}><i className="bi bi-x-lg"></i></button>


        {/* files box */}
        <div className='FilesBox'>
          <h3>Trash Files</h3>

          {/* trash files div */}
          <div className='FilesDiv'>



          </div>
        </div>

      </div>
    )
  }
}
