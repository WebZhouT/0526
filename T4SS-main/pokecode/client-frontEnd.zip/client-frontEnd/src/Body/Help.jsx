import React, { Component } from 'react'

export default class Help extends Component {
  render() {
    const { changeFlagHelp } = this.props
    return (
      <div className='settingBox'>
        <div className='settingDiv' style={{ height: '80%' }}>
          <button onClick={() => {
            changeFlagHelp()
          }} style={{ position: 'absolute', right: '10px', top: '10px', border: 'none', background: 'transparent' }}><i className="bi bi-x-lg"></i></button>

          {/* Help box */}
          <div style={{ display: 'flex', flexDirection: 'column', width: '95%', height: '90%', alignItems: 'center',backgroundColor:'red' }}>

            <h2>Help Board</h2>

          </div>


        </div>

      </div>
    )
  }
}
