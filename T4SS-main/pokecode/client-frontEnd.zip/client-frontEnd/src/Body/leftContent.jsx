import React, { Component } from 'react'
import logo from './note-taking.png'
import axios from 'axios'
import FileDiv from './components/FileDiv'

export default class LeftContent extends Component {
  // localhost
  lh = 'http://localhost:9999'

  state = {
    folderList: [],
    folderId: '',
    myarr: [],
    searchBar: false

  }


  // Remove cookies => after user login (id, username, token)
  getCookie = (i) => {
    var arr = document.cookie.match(new RegExp("(^|\\s)" + i + "=([^;]+)(;|$)"));
    if (arr != null) {
      return decodeURIComponent(arr[2]);//1
    } else {
      return null;
    }
  }
  removeCookie = (e) => {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = this.getCookie(e);
    if (cval) {
      document.cookie = e + "=" + cval + ";expires=" + exp.toUTCString();
      return cval
    }
  }


  // get folder list
  componentDidMount = async () => {
    const a = await axios({
      headers: { 'Content-Type': 'application/json' },
      method: 'POST',
      url: this.lh + '/api/folder/list'
    }).catch(e => {
      console.log('Went wrong');
    })
    this.setState({
      folderList: a.data.data
    })
  }

  //get notes list in trash
  // componentDidMount = async (id) => {
  //   var uidTrash = this.getCookie('id');
  //   const a = await axios({
  //     headers: { 'Content-Type': 'application/json' },
  //     method: 'GET',
  //     url: this.lh + '/api/note/clear'+uidTrash,
  //   }).catch(e => {
  //     console.log('Went wrong');
  //   })
  //   this.setState({
  //     folderList: a.data.data
  //   })
  // }

  saveFoldersToCookie = (folderList) => {

    var date = new Date().getTime();
    var newD = new Date(date + 30 * 24 * 60 * 60 * 1000);//加上有效期时间后再转换成时间对象

    document.cookie = "folders=" + JSON.stringify(folderList) + "; expires=" + newD.toUTCString();

  }


  render() {
    const { folderList, myarr, searchBar} = this.state
    const { changeFlagSigninAndSignup, changeFlagSearchOwnFiles, username, changeFlagResetPwd, changeFlagFeedback, changeFlagHelp, changeFlagStarredFiles, changeFlagTrash, changeFlagSearchOtherNotes, receiveNote } = this.props

    this.saveFoldersToCookie(folderList);

    return (


      // Logo and username Display after user login (Default:Guest)
      <div style={{ height: 100 + '%' }}>
        <div className='navDiv' style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div className='circle' style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <img src={logo} alt="note-taking logo" style={{ width: '300px' }} />
          </div>
          <span id='user' style={{ paddingTop: '20px', fontWeight: 'Bold', fontSize: '18px', color: '#2D6CCB' }}>{username}</span>
        </div>




        {/* Home */}
        <div className='navDiv'>
          <button className='navDivBtn' onClick={() => {
            changeFlagStarredFiles(false);
            changeFlagTrash(false);
            changeFlagSearchOwnFiles(false);
            changeFlagSearchOtherNotes(false)
          }}>
            <i className="bi bi-house-heart"></i>&nbsp;&nbsp;&nbsp;&nbsp;Home
          </button>
        </div>

        {/* Trash */}
        <div className='navDiv'>
          <button className='navDivBtn' onClick={() => {
            changeFlagTrash(true);
            changeFlagStarredFiles(false);
            changeFlagSearchOwnFiles(false);
            changeFlagSearchOtherNotes(false)
          }}><i className="bi bi-trash"></i>&nbsp;&nbsp;&nbsp;&nbsp;Trash
          </button></div>

        {/* NoteBook */}
        <div className='navDiv' style={{ display: 'flex', flexDirection: 'column', marginTop: '5px' }}>
          {/* Notebook title */}
          <div><i className="bi bi-folder2"></i>&nbsp;&nbsp;&nbsp;&nbsp;Notebook</div>

          <div style={{ height: '10%', marginTop: '5px' }}>

            {/* Notebook folder file functions */}
            <div>

              {/* Search user's own files components */}
              <button title='Search own files' style={{ border: 'none', background: 'transparent', float: 'right' }} onClick={() => {
                changeFlagSearchOwnFiles(true);
                changeFlagSearchOtherNotes(false);
                changeFlagTrash(false);
                changeFlagStarredFiles(false);
              }}><i className="bi bi-search"></i></button>
            </div>

            {/* delete the folder */}
            <button title='delete the folder' style={{ border: 'none', background: 'transparent', float: 'right' }} onClick={()=>{
              var foldername = document.getElementById('foldername').value;
              if (folderList.length >0){
                folderList.forEach((item)=>{
                  if(item.name === foldername){
                    axios({
                      headers: { 'Content-Type': 'application/json' },
                      method: 'DELETE',
                      url: this.lh + '/api/folder/'+item.id,
                    })
                  }
                })
                window.location.reload()
              }else{
                alert("No folder in database")
              }
            }} ><i className="bi bi-trash"></i></button>

            {/* edit the folder */}
            <button title='edit the folder' style={{ border: 'none', background: 'transparent', float: 'right' }} onClick={()=>{
              this.setState({
                searchBar: !this.state.searchBar
              })
            }}><i className="bi bi-pencil-square"></i></button>


            {/* foldername save */}
            <input type="text" placeholder='foldername' id='foldername' style={{ width: '13em', height: '30px', fontSize: '12px', marginTop: '1px', marginLeft: '8px', borderRadius: '10px', border: '1px solid #0367a6' }} />
            <button title='save as a folder' style={{ border: 'none', background: 'transparent', float: 'right' }} onClick={async() => {
              var foldername = document.getElementById('foldername').value;
              var uid = this.getCookie('id');
              var t = this.getCookie('token');
              let jsonFolder = JSON.stringify({ name: foldername,userId: uid});
              console.log(uid);
              if (myarr.includes(foldername)) {
                alert('The folder name already exists, please enter another folder name.')
              } else {
                await axios({
                  headers: { 
                    'Content-Type': 'application/json',
                    'x-api-token': t
                 },
                  method: 'POST',
                  url: this.lh + '/api/folder',
                  data: jsonFolder
                }).then(e => {
                  // window.location.reload()
                  console.log('我是folder接口结果',e);
                  
                })
                window.location.reload()
              }
            }
            }
            ><i className="bi bi-folder-plus"></i></button>

          </div>
          {searchBar? <div>
            <input type="text" placeholder='foldername' id='newFoldername' style={{ width: '13em', height: '30px', fontSize: '12px', marginTop: '1px', marginLeft: '8px', borderRadius: '10px', border: '1px solid #0367a6' }} /> <button onClick={()=>{
              var foldername = document.getElementById('foldername').value;
              var newFoldername = document.getElementById('newFoldername').value;
              if (folderList.length >0){
                folderList.forEach((item)=>{
                  if(item.name === foldername){
                    let id = item.id
                    let jsonFolder = JSON.stringify({ name: newFoldername, id: id });
                    axios({
                      headers: { 'Content-Type': 'application/json' },
                      method: 'PUT',
                      url: this.lh + '/api/folder',
                      data: jsonFolder
                    })
                  }
                })
                window.location.reload()
              }else{
                alert("No folder in database")
              }
            }}>Change</button>
          </div>:''}

          {/* Notebook display result body */}
          <div style={{ width: '100%', height: '405px', marginTop: '5px', overflowY: "scroll" }}>
            <FileDiv folderList={folderList} receiveNote = {receiveNote}/>
          </div>
        </div>





        {/* Login/Register components */}
        <div className='navDiv' style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>

          {/* User Signup/Signin button */}
          <button className="btn btn-outline-primary" style={{ width: '80%', height: '30%', marginTop: '15px', fontWeight: 'Bold', fontSize: '18px' }} onClick={() => {
            changeFlagSigninAndSignup()
          }}>Sign Up&nbsp;/&nbsp;Sign In</button>


          {/* User Sign out button */}
          <button className="btn btn-outline-primary" style={{ width: '80%', height: '30%', marginTop: '15px', fontWeight: 'Bold', fontSize: '18px' }} onClick={() => {

            axios({
              headers: {
                'Content-Type': 'application/json',
                'x-api-token': this.getCookie('token')
              },
              method: 'POST',
              url: this.lh + '/api/logout'
            }).then(e => {
              if (e.data.code === 200) {
                alert('Sign out successfully!');
                document.querySelector('#user').innerHTML = 'Guest'
              }
            })

            this.removeCookie('id');
            this.removeCookie('username');
            this.removeCookie('token');


          }
          }
          >Sign Out</button>
        </div>



        {/* Setting */}
        <div className='navDiv'>

          <button className="btn dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style={{ height: '32px'}}>
            <i className="bi bi-gear"></i>
          </button>

          <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">

            {/* Reset password */}
            <li><button className="dropdown-item" onClick={() => {
              changeFlagResetPwd()
            }}>Reset password</button></li>

            {/* User feedback */}
            <li><button className="dropdown-item" onClick={() => {
              changeFlagFeedback()
            }}>Feedback</button></li>

            {/* Help */}
            <li><button className="dropdown-item" onClick={() => {
              changeFlagHelp()
            }}>Help<i className="bi bi-question-circle"></i></button></li>
          </ul>
        </div>

      </div >
    )
  }
}
