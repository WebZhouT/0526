import React, { Component } from 'react'

export default class StarredFiles extends Component {
  render() {
    const { changeFlagStarredFiles } = this.props
    return (

      <div style={{width:'100%',height:'100%',backgroundColor:'green'}}>
        {/* close button */}
        <button onClick={() => {
          changeFlagStarredFiles(false)
        }} style={{ float: 'right', border: 'none', background: 'transparent' }}><i className="bi bi-x-lg"></i></button>


        {/* files box */}
        <div className='FilesBox'>
          <h3>Starred Files</h3>
          {/* starred files div */}
          <div className='FilesDiv'>

          </div>
        </div>

      </div>
    )
  }
}
