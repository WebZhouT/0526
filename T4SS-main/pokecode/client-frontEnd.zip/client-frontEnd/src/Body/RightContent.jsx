import React, { Component } from 'react'

export default class RightContent extends Component {
  render() {
    return (
      <div style={{ height: '100%' }}>
        {/* function bar */}
        <div className='functionBar'>
          {/* text */}
          <button title='Text style'><i className="bi bi-fonts" ></i></button>
          {/* Undo */}
          <button title='Undo'><i className="bi bi-arrow-90deg-left"></i></button>
          <button title='Forward'><i className="bi bi-arrow-90deg-right"></i></button>
          {/* run */}
          <button title='Run'><i className="bi bi-caret-right-fill"></i></button>


          {/* Save select */}
          <button title='Save as' className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style={{ float: 'right', fontSize: '23px', color: 'black', position: 'relative', bottom: '6px', height: '43px' }}>
            <i className="bi bi-save"></i>
          </button>
          <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
            <li><button className="dropdown-item" >.py</button></li>{/* Python */}
            <li><button className="dropdown-item">.java</button></li>{/* Java */}
            <li><button className="dropdown-item">.c</button></li>{/* C */}
            <li><button className="dropdown-item">.cpp</button></li>{/* C++ */}

          </ul>

          {/* Language select */}
          <button title='Language Select' className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style={{ float: 'right', fontSize: '23px', color: 'black', position: 'relative', bottom: '6px', height: '43px' }}>
            <i className="bi bi-file-earmark-code"></i>
          </button>
          <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
            <li><button className="dropdown-item">Python</button></li>
            <li><button className="dropdown-item">Java</button></li>
            <li><button className="dropdown-item">C</button></li>
            <li><button className="dropdown-item">C++</button></li>
          </ul>
        </div>

        {/* Note/Code */}
        {/* https://medium.com/weekly-webtips/enable-line-numbering-to-any-html-textarea-35e15ea320e2 */}
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
          <textarea id="textArea" name="note_code_textArea" style={{ width: '90%', maxHeight: '600px', marginTop: '10px', marginBottom: '10px' }} placeholder='Type your code here...'></textarea>
          <button style={{ position: 'relative', left: '500px' }}>Clear</button>
          <div style={{ width: '90%', height: '350px', marginTop: '10px', backgroundColor: 'grey' }}>
            result dispaly
          </div>
        </div>

      </div>
    )
  }
}
