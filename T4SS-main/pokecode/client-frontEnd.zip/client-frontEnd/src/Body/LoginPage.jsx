import React, { Component } from 'react'

export default class LoginPage extends Component {

  render() {
    const { changeFlagLogin } = this.props
    return (
      <div className='LoginBG' >
        <div className="login" style={{position:'relative'}}>
          <button onClick={() => {
            changeFlagLogin()
          }} style={{ position: 'absolute', right: '0px' }}><i className="bi bi-x-circle"></i></button>

          <div style={{position:'absolute',top:'80px',left:'50px'}}>
            <h2>User Login</h2>
            <br />
            Username
            <br />
            <input type="text" placeholder='Phone number/Email Address' style={{width:"300px"}}/>
            <br />
            <br />
            <br />
            Password
            <br />
            <input type="password" placeholder='Password' style={{width:"300px"}}/>
          </div>
          <button style={{position:'absolute',bottom:'10px',left:'168px'}}>Login</button>


        </div>
      </div>
    )
  }
}
