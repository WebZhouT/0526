import React, { useEffect, useState } from 'react';
import axios from 'axios';

function FileDiv(props) {
  // localhost
  const lh = 'http://localhost:9999'
  const [folderList, setFolderList] = useState(props.folderList)
  const [resObj,setResObj] = useState({})
  const getCookie = (i) => {
    
    var arr = document.cookie.match(new RegExp("(^|\\s)" + i + "=([^;]+)(;|$)"));
    if (arr != null) {
      return decodeURIComponent(arr[2]);//1
    } else {
      return null;
    }
  }
  const uID = getCookie('id');
  async function getFiles(fid) {
    return axios({
      headers: { 'Content-Type': 'application/json' },
      method: 'POST',
      url: lh + '/api/note/list',
      data: {
        folderId: fid,
        userId: uID
      }
    }).catch(e => {
      console.log('Went wrong');
    })
  }

  async function awaitPromise(e){
    const a = await e
    setfFolder(a)
  }
  const [filesInFolder,setfFolder]= useState({});

  useEffect(() => {
    let tempObj  = {}
    setFolderList(props.folderList)
    const promiseList =[]
    folderList.forEach(e => {
      tempObj[e.id] = []
      promiseList.push(getFiles(e.id))
    })
    setResObj(tempObj)
    awaitPromise(Promise.all(promiseList))
  }, [props])

  useEffect(()=>{
    let tempObj  = JSON.parse(JSON.stringify(resObj))
    let count = 0;
    for (let i in resObj){
      tempObj[i] = filesInFolder[count++]?.data?.data
    }
    setResObj(tempObj)
  },[filesInFolder])

  return (
    <div>
      <div className="accordion accordion-flush" id="accordionFlushExample">
        {

          folderList.map((e, index) => {
            return (
              <div className="accordion-item" key={index}>
                <div className="accordion-header" id={"flush-headingOne" + index}>
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target={"#flush-collapseOne" + index} aria-expanded="false" aria-controls={"flush-collapseOne" + index}>
                    {e.name}
                  </button>
                </div>

                <div id={"flush-collapseOne" + index} className="accordion-collapse collapse" aria-labelledby={"flush-headingOne" + index} data-bs-parent="#accordionFlushExample">
                  <div className="accordion-body">
                    {
                      Array.isArray(resObj[e.id]) ? (
                        resObj[e.id].map((item,index) => {
                          return<div  key={''+index+'-'+e.id}><button onClick={()=>{props.receiveNote(item.content, item.id)}}>{item.name}</button></div>
                        })
                      ):''
                    }
                  </div>
                </div>
              </div>
            )
          })
        }

      </div>
    </div>
  )

}

export default FileDiv