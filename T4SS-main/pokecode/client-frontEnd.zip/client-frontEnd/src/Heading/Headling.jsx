import React, { Component } from 'react'

export default class Headling extends Component {
  render() {
    return (
      <div className = 'headingBox'>
        {/* <span className='icon' style={{marginTop:'10px'}}><img width={30} src={require('./note-taking.png')} alt="" /></span> */}
        <span><i className="bi bi-journal-code" style={{fontSize:30+'px'}}></i></span>
        <span className='content'><b>Pokécode</b></span>
      </div>
    )
  }
}
